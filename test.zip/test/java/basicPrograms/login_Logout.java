package basicPrograms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class login_Logout 
{

	public static void main(String[] args) throws Exception
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.araahskinmiracle.com/my-account/");
		Thread.sleep(2000);
		driver.findElement(By.name("username")).sendKeys("meda.bhaskarrao@gmail.com");		
		Thread.sleep(2000);
		driver.findElement(By.id("password")).sendKeys("Meda@90524");
		Thread.sleep(2000);
		driver.findElement(By.name("login")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"site-content\"]/div/div/div/div/nav/ul/li[6]/a")).click();
		driver.close();
		
	}

}
