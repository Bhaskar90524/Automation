package browserTesting;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

public class Cross {
  @Test
  public void differentBrowser() 
  {
	  Scanner s=new Scanner(System.in);
	  System.out.println("*******WELCOME BROWSERS************");
	  System.out.println("Enter 1 for Google chrome \nEnter 2 for Microsoft Edge \nEnter 3 for Firefox");
	  int choice=s.nextInt();
	  
	  switch(choice)
	  {
	  case 1:
		  System.out.println("\nWelcome to Google chrome");
		  System.setProperty("WebDriver.chrome.driver", "C:\\Users\\medab\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe");
		  WebDriver driver=new ChromeDriver();
		  driver.get("https://www.araahskinmiracle.com/my-account/");
		  driver.findElement(By.name("username")).sendKeys("meda.bhaskarrao@gmail.com");		
	      driver.findElement(By.id("password")).sendKeys("Meda@90524");
		  driver.findElement(By.name("login")).click();
		  driver.findElement(By.xpath("//*[@id=\"site-content\"]/div/div/div/div/nav/ul/li[6]/a")).click();
		  driver.close();
		  break;
		  
	  case 2:
		  System.out.println("\nWelcome to Microsoft Edge");
		  System.setProperty("WebDriver.chrome.driver", "C:\\Users\\medab\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\msedgedriver.exe");
		  WebDriver driver1=new EdgeDriver();
		  driver1.get("https://www.araahskinmiracle.com/my-account/");
		  driver1.findElement(By.name("username")).sendKeys("meda.bhaskarrao@gmail.com");		
	      driver1.findElement(By.id("password")).sendKeys("Meda@90524");
		  driver1.findElement(By.name("login")).click();
		  driver1.findElement(By.xpath("//*[@id=\"site-content\"]/div/div/div/div/nav/ul/li[6]/a")).click();
		  driver1.close();	  
		  break;
		  
	  case 3:
		  System.out.println("\nWelcome to Firefox");
		  System.setProperty("WebDriver.chrome.driver", "C:\\Users\\medab\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\geckodriver.exe");
		  WebDriver driver2=new EdgeDriver();
		  driver2.get("https://www.araahskinmiracle.com/my-account/");
		  driver2.findElement(By.name("username")).sendKeys("meda.bhaskarrao@gmail.com");		
	      driver2.findElement(By.id("password")).sendKeys("Meda@90524");
		  driver2.findElement(By.name("login")).click();
		  driver2.findElement(By.xpath("//*[@id=\"site-content\"]/div/div/div/div/nav/ul/li[6]/a")).click();
		  driver2.close();	 	  
		  break;
		  
	  }
  }
}
