package basicPrograms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Registration 
{

	public static void main(String[] args) throws Exception 
	{
		WebDriverManager.chromedriver().setup();
		WebDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
		Thread.sleep(2000);

		driver.get("https://www.araahskinmiracle.com/my-account/");
		driver.findElement(By.id("reg_username")).sendKeys("Bhaskar");
		Thread.sleep(2000);
		driver.findElement(By.name("email")).sendKeys("meda.bhaskarrao@gmail.com");		
		Thread.sleep(2000);
		driver.findElement(By.id("reg_password")).sendKeys("Meda@90524");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"customer_login\"]/div[2]/form/p[4]/button")).click();
		
	}

}
