package hybrid;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class OperationalClass 
{
 public void maximizeBrowser(WebDriver driver) 
	{
		driver.manage().window().maximize();
	}
	public void url(WebDriver driver)
	{
		driver.get("https://www.araahskinmiracle.com/my-account/");
	}
	
	public void username(WebDriver driver, String usn)
	{
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys(usn);
	}
	
	public void password(WebDriver driver, String pwd)
	{
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(pwd);
	}
	
	public void loginButton(WebDriver driver)
	{
		driver.findElement(By.xpath("//button[@type='submit']")).click();
	}
	
	public void smokeTesting(WebDriver driver) throws Exception
	{
		//Mouse Hover:
		//Step 1:Create Object of Action Class
		Actions a= new Actions(driver);
	
		//Step 2: Create List for WebElements
		List<WebElement>ls=driver.findElements(By.xpath("//ul[@id='menu-main-menu-2']/li"));
	
		//Step 3:Storing size of list
		int size=ls.size();
		System.out.println("No of webelements: "+size);
	
		//Step 4: For Loop
		for(int i=1; i<=8; i++)
		{
			//Wait
			Thread.sleep(2000);
			
			//Display web-element name
			System.out.println(driver.findElement(By.xpath("//ul[@id='menu-main-menu-2']/li["+i+"]")).getText());
		
			//Perform Mouse Hover
			a.moveToElement(driver.findElement(By.xpath("//ul[@id='menu-main-menu-2']/li["+i+"]"))).click().perform();
		}
	}
		public void welcomeAdmin(WebDriver driver)
		{
			driver.findElement(By.xpath("//*[@id=\"masthead\"]/div/div[1]/div[1]/div/div[3]/div/div[1]")).click();
		}
		
		public void logoutbutton(WebDriver driver)
		{
			driver.findElement(By.linkText("Logout")).click();
		}
		
		public void closeBrowser(WebDriver driver)
		{
			driver.close();
		}	
}
