package hybrid;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MainClass
{

	public static void main(String[] args) throws Exception 
	{
		//Launch Browser
		System.setProperty("webdriver.chrome.driver","C:\\Users\\medab\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		Thread.sleep(2000);
		
		//Create object of ReadExcel Class
		ReadExcel r= new ReadExcel();
		r.readExcel(driver);
	}
}