package hybrid;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;

public class ReadExcel
{
	public void readExcel(WebDriver driver) throws Exception
	{
		// Excel Sheet
		FileInputStream file = new FileInputStream("C:\\Users\\medab\\OneDrive\\Desktop\\Automation Testing\\Aarah\\POI.xlsx");
		XSSFWorkbook w = new XSSFWorkbook(file);
		XSSFSheet s = w.getSheet("HybridFramework");

		int size = s.getLastRowNum();
		System.out.println("No Of data: " + size);

		OperationalClass o = new OperationalClass();

		for (int i = 1; i <= size; i++) // DataDriven Framework
		{
			String username = s.getRow(i).getCell(1).getStringCellValue();
			String password = s.getRow(i).getCell(2).getStringCellValue();
			System.out.println(username + "\t\t" + password);

			try
			{
				// Login
				for (int j = 1; j <= size; j++)// keyword Driven Framework
				{
					String key = s.getRow(j).getCell(0).getStringCellValue();

					if (key.equals("Maximize Browser")) 
					{
						o.maximizeBrowser(driver);
						System.out.println(key);
						Thread.sleep(2000);
					} 
					else if (key.equals("Enter URL"))
					{
						o.url(driver);
						System.out.println(key);
						Thread.sleep(2000);
					} 
					else if (key.equals("Enter Username")) 
					{
						o.username(driver, username);
						System.out.println(key);
						Thread.sleep(2000);
					}
					else if (key.equals("Enter Password"))
					{
						o.password(driver, password);
						System.out.println(key);
						Thread.sleep(2000);
					} 
					else if (key.equals("Click On Login Button")) 
					{
						o.loginButton(driver);
						System.out.println(key);
						Thread.sleep(3000);
					} 
					else if (key.equals("SmokeTesting")) 
					{
						
						o.smokeTesting(driver);
						System.out.println(key);
						Thread.sleep(2000);
					}
					else if (key.equals("Click On Welcome Admin Button"))
					{
						o.welcomeAdmin(driver);
						System.out.println(key);
						Thread.sleep(5000);
					}
					else if (key.equals("Click On Logout Button"))
					{
						o.logoutbutton(driver);
						System.out.println(key);
						Thread.sleep(2000);
						System.out.println("Valid Credentials.");
						System.out.println("");
						s.getRow(i).createCell(3).setCellValue("Valid Credentials.");
						
					}
				}
			} 
			catch (Exception e) 
			{
				System.out.println("Invalid Credentials.");
				System.out.println("");
				s.getRow(i).createCell(3).setCellValue("Invalid Credentials.");
			}
		}
		o.closeBrowser(driver);
		FileOutputStream out= new FileOutputStream("C:\\Users\\medab\\OneDrive\\Desktop\\Automation Testing\\Aarah\\POI.xlsx");
		w.write(out);
	}
}
