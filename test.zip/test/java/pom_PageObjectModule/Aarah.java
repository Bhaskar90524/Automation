package pom_PageObjectModule;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class Aarah
{


	public void maximizeBrowser(WebDriver driver)
	{
		driver.manage().window().maximize();
	}
	public void url(WebDriver driver)
	{
		driver.get("https://www.araahskinmiracle.com/my-account/");
	}
	
	public void username(WebDriver driver, String usn)
	{
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys(usn);
	}
	
	public void password(WebDriver driver, String pwd)
	{
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(pwd);
	}
	
	public void loginButton(WebDriver driver)
	{
		driver.findElement(By.xpath("//button[@type='submit']")).click();
	}
	
	
	public void logoutButton(WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"menu-footer-useful-links-1\"]/li[4]/a")).click();	
	}
	
	public void closeBrowser(WebDriver driver)
	{
		driver.close();
	}
 

 
 }