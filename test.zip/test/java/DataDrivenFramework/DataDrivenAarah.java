package DataDrivenFramework;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import pom_PageObjectModule.Aarah;



public class DataDrivenAarah
{

	public void DataDriven() throws Exception, IOException
	{
		//Store Excel Path
		FileInputStream file = new FileInputStream("C:\\Users\\medab\\OneDrive\\Desktop\\Automation Testing\\Aarah\\POI.xlsx");
		//Excel File
		XSSFWorkbook w= new XSSFWorkbook(file);
		//Excel Sheet
		XSSFSheet s=w.getSheet("DataDrivenAarah");
		//Store no. of rows
		int size=s.getLastRowNum();
		System.out.println("No Of Credentials: "+size);
		
		//Launch GoogleChrome
		System.setProperty("webdriver.chrome.driver","C:\\Users\\medab\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		
		//Create object of POM Class >> Login+Logout
		Aarah o=new Aarah();
		o.maximizeBrowser(driver);
		Thread.sleep(2000);
		
		//For Loop >> To Read Multiple credentials
		for(int i=1; i<=size; i++)
		{
			//Store Credentials in varaibles
			String username=s.getRow(i).getCell(0).getStringCellValue();
			String password=s.getRow(i).getCell(1).getStringCellValue();
			System.out.println(username+"\t\t"+password);
			
			//To handle exception
			try
			{
				//Login
				o.url(driver);
				Thread.sleep(2000);
				o.username(driver, username);
				Thread.sleep(2000);
				o.password(driver, password);
				Thread.sleep(2000);
				o.loginButton(driver);
				Thread.sleep(5000);
				o.logoutButton(driver);
				Thread.sleep(2000);
				//If credential is correct it will print valid data on console as well as in excel sheet
				System.out.println("Valid username and password.");
				System.out.println("");
				s.getRow(i).createCell(2).setCellValue("Valid username and password.");
				}
			catch(Exception e)
			{
				//If credential is incorrect it will handle by CATCH block and print invalid data on console as well in excel sheet
				
				System.out.println("Invalid username and password.");
				System.out.println("");
				s.getRow(i).createCell(2).setCellValue("Invalid username and password.");
			}
		
		}
		//Write data
		FileOutputStream out= new FileOutputStream("C:\\Users\\medab\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\POI.xlsx");
		w.write(out);			
	}
}