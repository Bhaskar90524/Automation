package basicPrograms;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.google.common.io.Files;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AddToCart {

	public static void main(String[] args) throws InterruptedException, IOException 
	{
		//Select s;
		WebDriverManager.chromedriver().setup();
		WebDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.araahskinmiracle.com/my-account/");
		Thread.sleep(2000);
		driver.findElement(By.name("username")).sendKeys("meda.bhaskarrao@gmail.com");		
		Thread.sleep(2000);
		driver.findElement(By.id("password")).sendKeys("Meda@90524");
		Thread.sleep(2000);
		driver.findElement(By.name("login")).click();
		Thread.sleep(2000);
		driver.findElement(By.linkText("Body")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"menu-main-menu-2\"]/li[3]/div/div/ul/li[3]/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"la_shop_products\"]/div[3]/div/ul/li/div/div[2]/div[1]/h3/a")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"wsatc-stick-cart-wrapper\"]/div/div[2]/a")).click();
		Thread.sleep(2000);
		
		//Scroll down
	    JavascriptExecutor js = (JavascriptExecutor)driver;
		Thread.sleep(2000);
	    
		js.executeScript("window.scrollBy(0,600)");
    
		
		
		File f = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	    Files.copy(f, new File("/Automation_FinalProject/src/test/resources/Screenshots\\Addtocart.jpg"));
		

	}

}
